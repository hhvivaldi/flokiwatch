# FlokiWatch — Complete Session Handoff
## Session: March 13-16, 2026 (Weekend Marathon)
## Para: Próxima conversa Claude (mesmo projecto)

---

# WHAT IS FLOKIWATCH
AI-powered gold (XAU/USD) trading bot. Claude Sonnet 4 = "Floki" (senior trader, decides). GPT-4o = "Rex" (junior trader, debates). Runs on MetaTrader 5, demo account $816.97 balance.

---

# WHAT WE BUILT THIS WEEKEND

## Major Architecture Change: Workflow → Real Agent with Tool Use
- BEFORE: Python built XML → called Claude 1x → got JSON → Python executed
- AFTER: Python triggers Claude → Claude CHOOSES which tools to call → sees results → reasons → acts

## Key Commits (latest first, most important ones):
- `ec0f72e` — feat: log prompt cache usage
- `d1216dd` — feat: enable Anthropic prompt caching for system prompt + tools
- `4103032` — fix: accept entry_conditions as trade plan in proactive execution
- `b35f98d` — fix: prompt requires mandatory watch conditions on HOLD_TRADE
- `e4ed747` — fix: hide technical metadata from Trade Room + Floki speaks directly to Rex
- `af5dca2` — fix: Trade Room price formatting (2 decimals) + trend arrow indicator
- `95d45c5` — fix: Rex debate quality — no repeated concerns + natural speech
- `2351bdd` — feat: Rex upgrade — personality + market data access + natural conversation
- `8cc35a8` — feat: multi-timeframe fibonacci (H1/H4/D1)
- `a1f54a4` — fix: accept entry_price in agent trade_plan validation
- `be2e0dc` — fix: inject cached candles from analysis cycle into proactive path
- `87d7ff1` — fix: remove orphan _record_synthetic_agent_close from monitor.py
- `03f9287` — fix: increase agent limits (25 tools, 120s timeout) + M5 candles backfill
- `0f40e4d` — fix: complete schema bridge — candles backfill + headlines + ML mapping
- `32203df` — fix: compute fibonacci levels for agent tools from H1 candles
- `e31a259` — fix: cache M5/H4/D1 candles for agent tools
- `11c11f2` — fix: critical — map scanner output to agent tools schema (field name mismatch)
- `1e2a93a` — fix: log all agent tool calls including cache misses
- `4217a62` — fix: move hardcoded NewsAPI key to environment variable

---

# WHAT IS CONFIRMED WORKING (with log/production evidence)

1. **Tool use loop** ✅ — Agent calls 15-25 tools per decision, sees real results
2. **Session memory** ✅ — Agent writes/reads notes between calls (write_session_memory | notes_count=10)
3. **Debate Floki-Rex** ✅ — Real debates with specific data, Rex uses market data, natural language
4. **execute_trade tool** ✅ — Agent opens trades via tool (SELL @ 4989.3, ticket=0, success)
5. **Reflection engine** ✅ — 64 trades, 11 patterns, 123ms on startup
6. **Balance diff** ✅ — P&L tracked per trade (BALANCE_DIFF lines in log)
7. **Deal resolver N2.5** ✅ — Finds trades via today-only search when N1/N2 fail
8. **Schema bridge** ✅ — Scanner output correctly mapped to Agent tools schema
9. **Candles multi-TF** ✅ — H1/H4/D1/M5 all available (candles_keys=['H1', 'M5', 'H4', 'D1'])
10. **Fibonacci multi-TF** ✅ — H1/H4/D1 levels computed (tfs=H1,H4,D1)
11. **Indicators** ✅ — RSI, MACD, ATR, ADX, EMA, Bollinger via tools
12. **S/R zones** ✅ — 58 zones (D1:7, H4:49, H1:2, 46 strong, 13 MTF)
13. **Macro** ✅ — DXY, VIX, 10Y yields via get_macro tool
14. **Headlines** ✅ — RSS headlines via get_headlines (count=8)
15. **Calendar** ✅ — Economic calendar via get_calendar
16. **ML prediction** ✅ — Ensemble 6 models via get_ml_prediction
17. **Monitor events** ✅ — BROKER_CLOSE events recorded in agent_monitor_events.json
18. **Watch conditions SET** ✅ — Agent calls set_watch_conditions (ticket=1534798787, count=3)
19. **Watch conditions EVALUATED** ✅ — Monitor shows conditions=present in logs
20. **entry_conditions fallback** ✅ — Agent OPEN intents execute via entry_conditions schema
21. **Rex natural conversation** ✅ — Rex speaks naturally, references specific data
22. **Prompt caching** ✅ — Cache rate ~40-50% confirmed (saves ~45% on input costs)
23. **Trade Room** ✅ — Price 2 decimals, debates visible, KEY DATA hidden
24. **GPT Headlines OFF** ✅ — Using keywords only
25. **Central Scanner ON** ✅ — Not "Brain"
26. **Timeout 120s** ✅ — No more timeouts during debate
27. **Max 25 tool calls** ✅ — Enough for investigation + debate + execution
28. **NameError fix** ✅ — _record_synthetic_agent_close removed, no more crash loop
29. **Fast Agent** ✅ — TRADE_RISK_SL trigger correctly closed a losing trade
30. **Position events visible to Floki** ✅ — get_position_events returns count=8

---

# WHAT IS PENDING VERIFICATION (needs natural market events)

1. **Watch conditions TRIGGER** — Conditions are set and evaluated, but NO condition has been TRIGGERED yet (price hasn't reached the defined levels). Need to see: "WATCH_CONDITION triggered" in logs when price touches a level.

2. **FAST_CLOSE event in monitor events** — Fast Agent closing a trade AFTER the fix that writes FAST_CLOSE to agent_monitor_events.json. Currently only BROKER_CLOSE entries exist. Need a Fast Agent close to happen naturally.

3. **BE/trailing customizable by Agent** — Agent can specify custom breakeven/trailing in trade_plan, but not confirmed these values reach the EA Bridge brain_signal.json with correct conversion (points → pips × 10).

4. **Loss balance counter-examples** — get_trade_patterns shows counter_examples=0 every time. Need a losing trade with similar pattern to appear in the pattern analysis.

5. **Trade Room watch conditions display** — The JS in trade_room.html has NO wiring to read/render agent_watch_conditions.json. Shows "No active watch conditions" even when conditions exist. This is a UI task for a future session.

6. **Trade Room macro display** — Previously showed "—" for DXY/VIX/10Y. Not verified if the latest fix resolved this.

---

# KNOWN ISSUES / BUGS TO FIX

1. **AGENT_CHECKLIST warning** — Every proactive call shows: "AGENT_CHECKLIST | MISSING — agent did not include data_checklist". This is a prompt/format check that the Agent doesn't comply with. Low priority — doesn't affect trading.

2. **Rex still sometimes uses CONCERNS: headers** — Despite prompt saying not to, GPT-4o occasionally reverts to bullet-point format. The reinforcement prompt helps but isn't 100%.

3. **Candle backfill debug logs still present** — The cleanup commit removed FORCE_CANDLES_DEBUG etc but AGENT_CACHE | M5/H4/D1 backfill attempt lines STILL appear every cycle. These should be removed or downgraded to DEBUG level.

4. **Trade Room watch conditions not wired** — No JS code reads agent_watch_conditions.json. Placeholder text always shows.

---

# COST ANALYSIS

## March 16 (today — high due to 18+ debugging restarts):
- Claude API: $33.86 (10.5M input tokens)
- This is an OUTLIER — normal days are $3-5

## Prompt caching impact:
- Cache rate: ~40-50%
- Estimated saving: ~45% per call on input tokens
- Normal day with caching: ~$4-6/day (~$120-180/month)

## Further optimizations for future session:
- Reduce S/R zones sent to Agent from 58 to nearest 10 (saves ~30% tokens)
- Reduce candles (H1: 10 instead of 20, H4: 5 instead of 20)
- Skip proactive call when Scanner shows same HOLD with <5% score change
- These can reduce to ~$3-4/day

---

# TRADE PERFORMANCE (March 16)

| # | Ticket | Direction | Entry | Close | P&L | Reason |
|---|--------|-----------|-------|-------|-----|--------|
| 1 | 1533338040 | SELL | 4989.63 | 4987.93 | +$1.70 | Stop Loss (trailing) |
| 2 | 1533423388 | SELL | 4993.83 | 5024.81 | -$30.98 | Expert Advisor (Fast Agent close) |
| 3 | 1533484843 | SELL | 5019.14 | 5019.20 | -$0.06 | Stop Loss (breakeven) |
| 4 | 1533501118 | SELL | 5022.34 | 5021.51 | +$0.83 | Stop Loss (trailing) |
| 5 | 1533532889 | SELL | 5021.94 | 5016.79 | +$5.15 | Stop Loss (trailing) |
| 6 | 1533556194 | SELL | 5015.55 | 5013.31 | +$2.24 | Stop Loss (trailing) |
| 7 | 1533581735 | SELL | 4996.09 | 4986.58 | +$9.51 | Stop Loss (trailing) |
| 8 | 1533805473 | SELL | 5010.91 | 5020.38 | -$9.47 | Expert Advisor (Fast Agent close) |
| 9 | 1534167724 | SELL | 5002.47 | 4994.52 | +$7.95 | Stop Loss (trailing) |
| 10 | 1534210843 | SELL | 4995.35 | 4989.19 | +$6.16 | Stop Loss (trailing) |
| 11 | 1534798787 | BUY | 5024.59 | 4984.90 | -$39.69 | Stop Loss |

**Totals: 11 trades | 7W / 3L (1 BE) | WR 63.6% | P&L -$46.66**
**Balance: $863.63 → $816.97**

Key observation: The BUY trade (#11) was the biggest loss. Floki was bearish all day (10 SELLs) then switched to BUY at a high level. The price continued falling. This needs analysis — was it a good read that went wrong, or a bias flip without sufficient evidence?

---

# SYSTEM CONFIGURATION

- Model: Claude Sonnet 4 (claude-sonnet-4-20250514)
- Rex Model: GPT-4o
- Timeout: 120 seconds
- Max tool calls: 25
- Max debate turns: 5
- Risk per trade: 2%
- Max daily loss: 6%
- SL range: 50-800 pips
- Breakeven: 50% of SL (dynamic)
- Trailing: 70% of SL
- Mode: DEMO MT5
- Analysis interval: 60 seconds
- Monitor interval: 10 seconds
- GPT Headlines: OFF (keywords only)
- Prompt caching: ON (ephemeral)

---

# KEY FILES

- `main.py` — Orchestrator: analysis cycle, proactive agent calls, fast agent, trade execution, schema bridge
- `ai_agent.py` — Claude tool use loop, AgentResult, token tracking, cache control
- `agent_tools.py` — 19 tool implementations (cache-only + MT5 direct for portfolio)
- `agent_prompts.py` — Floki personality, tool guidance, Rex awareness, watch conditions mandatory
- `rex_validator.py` — Rex personality, natural language response, AGREE/DISAGREE parsing
- `central_brain.py` — Market scanner, scenario analysis, pillar scoring
- `monitor.py` — Position management (BE/trailing/timeout/drawdown), watch conditions evaluation, broker close detection
- `agent_monitor.py` — 6 triggers + entry conditions, calls Fast or Proactive Agent
- `agent_reflection.py` — L2 pattern discovery from 64 historical trades
- `agent_memory.py` — REJECT memory (available but forced null in state_writer)
- `executor.py` — MT5 order execution, position management
- `ea_bridge.py` — JSON protocol between Python and MT5 EA
- `state_writer.py` — Dashboard state (bot_state.json)
- `db_writer.py` — SQLite persistence (history.db)
- `alerts.py` — Discord alert routing
- `dashboard/server.py` — Flask dashboard backend
- `dashboard/static/trade_room.html` — Trade Room UI

---

# DATA FILES

- `data/history.db` — SQLite: trades, analyses, agent decisions, proactive analyses
- `data/bot_state.json` — Dashboard state (written every cycle)
- `data/agent_session_memory.json` — Floki's session notes (L1 memory)
- `data/agent_patterns.json` — Reflection engine discovered patterns (L2 memory)
- `data/agent_watch_conditions.json` — Watch conditions set by Floki
- `data/agent_monitor_events.json` — Monitor events (BROKER_CLOSE, FAST_CLOSE)

---

# MEMORY SYSTEM (FinMem Pattern)

- **L1 (HOT):** Session memory — daily notes, thesis, trade count. File: agent_session_memory.json
- **L2 (WARM):** Reflection engine — discovers patterns from 64 historical trades. 11 patterns found. Top: "RSI 30-40 SELL: 83.3% WR, PF 7.57, n=6". File: agent_patterns.json
- **L3 (COLD):** Full trade history in SQLite (history.db)

---

# FUTURE IMPROVEMENTS (discussed but NOT implemented)

1. **Cost optimization** — Reduce S/R zones to nearest 10, reduce candle counts, skip proactive when nothing changed. Target: $3-4/day from current $5-6/day.

2. **Trade Room watch conditions wiring** — JS needs to read agent_watch_conditions.json and render active conditions.

3. **Trade Room macro display** — Verify DXY/VIX/10Y show in the right panel (was showing "—" before).

4. **Backtest Agent** — Simulate Agent decisions against historical data.

5. **Refactor "Brain" → "Scanner"** — Rename all file references, variables, DB columns.

6. **Remove dead code** — format_proactive_xml, gpt_confidence.py, cycle_memory imports.

7. **Expansion** — WTI, EURUSD, BTCUSD (future).

8. **Demo → Live transition** — Code review gates, confidence threshold increases.

---

# DEVELOPER WORKFLOW

Hermano works with an external developer via Windsurf IDE (AI coding assistant). The developer:
- Must create a plan file before implementing
- Must get explicit approval before code changes
- Must commit with descriptive messages
- Must push to GitHub after each commit
- Cannot read .env files (gitignored)
- Hermano reviews via Claude (this conversation) acting as technical auditor

Communication style with developer: English, direct, specific. Include exact file names, function names, and line references. Always demand log evidence before marking features as confirmed.

---

# CRITICAL LESSONS LEARNED THIS SESSION

1. **Schema bridge was the biggest bug** — Scanner produced fields with different names than what Agent tools expected. Took hours to find because errors were silently swallowed by try/except.

2. **numpy structured records don't support .get()** — The candles conversion failed silently because `r.get("tick_volume")` doesn't work on numpy records. Must use `r["tick_volume"]`.

3. **Reference vs copy bugs are hard to debug** — Multiple attempts to fix candles cache failed because of dict copy/reference issues. Solution was to store candles separately in `self._cached_candles` and inject before agent_decide.

4. **The Agent returns different field names than expected** — entry_conditions with preferred_entry/sl/tp instead of trade_plan with entry/stop_loss/take_profit. Always accept multiple schemas.

5. **Rex was blind without data** — Originally Rex only saw Floki's summary text. Now receives full market data and produces much better debate.

6. **Prompt caching works** — 40-50% cache rate confirmed, significant cost savings with zero quality impact.

---

# DEBATE QUALITY IMPROVEMENTS (PRIORITY FOR NEXT SESSION)

The Floki-Rex debate improved significantly but still needs refinement. These are prompt changes only (rex_validator.py and agent_prompts.py).

## Current State (what's good):
- Rex references specific data (fibonacci levels, volume numbers, DXY values)
- Floki addresses Rex directly ("Rex, good catch on...")
- Rex evolves arguments between turns (doesn't repeat as much)
- Floki acknowledges Rex's points ("you're right about the volume")

## What Still Needs Fixing:

### 1. Rex is too LONG within each turn
Rex lists 5-7 concerns per turn instead of focusing on 1-2 strong points. A junior trader would say one sharp thing, not write an essay.

FIX: Add to Rex prompt: "Keep your response to 3-4 sentences MAX. Focus on your ONE strongest concern with specific data. If you have a second point, make it brief. Do not list multiple concerns — pick the most important one and argue it hard."

### 2. Rex always ends with "I suggest we monitor X"
Every Rex turn ends with a generic suggestion. It's formulaic and adds no value.

FIX: Add to Rex prompt: "Do NOT end with 'I suggest we monitor...' or 'Consider setting alerts for...'. Instead, end with your honest assessment: either challenge Floki's plan directly or tell him what specific condition would change your mind. Be direct."

### 3. Floki uses numbered lists "1) 2) 3) 4)" in debate
The Floki debate messages read like reports, not conversation.

FIX: Add to Floki debate prompt: "In debates, do NOT use numbered lists or bullet points. Speak in flowing sentences like you're talking to Rex at the trading desk. Example — BAD: 'I see issues: 1) Volume thin 2) RSI neutral 3) DXY rising 4) Pattern poor'. GOOD: 'Rex, volume is dead at 179 against 13k average — institutions aren't here. Without them, any move is just noise. Add the DXY pushing higher and there's no reason to be long gold right now.'"

### 4. Both are too polite / professional
Real traders are more direct. The conversation feels like a corporate meeting, not a trading desk.

FIX for Rex: "You respect Floki but you're not afraid to be blunt. Instead of 'I'm concerned about the potential for...' say 'Floki, that's a trap — look at the volume.' Be direct, not diplomatic."

FIX for Floki: "When debating Rex, be conversational and direct. Don't write analysis reports. Talk like you're at the desk with your team."

### 5. Rex agrees too easily
Rex almost always concedes after 1-2 turns. A good junior trader would push back harder.

FIX: Add to Rex prompt: "Don't concede just because Floki makes a good point. If you still see risk, say so: 'OK Floki, I hear you on the structural break, but my concern about volume hasn't changed — 179 ticks is 179 ticks. If you want to trade this, fine, but I want a tighter stop.' Only say AGREE if you genuinely believe the trade is sound after seeing ALL the data."

### 6. CONCERNS: headers still appear sometimes
Despite prompt instructions, Rex occasionally uses "CONCERNS:" with bullets.

FIX: Reinforce at END of Rex prompt (models pay more attention to final instructions): "ABSOLUTE RULE: No headers. No bullet points. No numbered lists. No 'CONCERNS:' or 'SUGGESTED ADJUSTMENT:' labels. Write ONLY in flowing paragraphs. Your last line must be just AGREE or DISAGREE — nothing else on that line."

### 7. Rex disagrees even AFTER Floki concedes (discovered post-v2)
In a live debate, Floki switched from BUY to WAIT saying "Rex, you've convinced me." But Rex STILL responded DISAGREE and continued arguing against the BUY that no longer existed. Rex won the debate but didn't recognize it.

Cause: The "don't concede easily" instruction (Fix 5) made Rex too aggressive. He now pushes back even when Floki already changed his mind.

FIX: Add to Rex prompt: "IMPORTANT: If Floki CHANGES his direction based on your concerns (for example switches from BUY to WAIT because of your risk points), acknowledge it and AGREE. You won the debate — don't keep arguing against a position Floki already abandoned."

### 8. Rex is NOT blind — he has full debate history
Rex receives the complete conversation transcript each turn (Turn 1 Floki + Rex, Turn 2 Floki + Rex, etc.). He also receives the full market data (same as Floki). The issue in #7 is NOT a memory problem — Rex sees the history but his "don't concede" instruction overrides his ability to recognize when he's won.

## Implementation status:
- Fixes 1-6: Implemented in commit fa06f6c (debate quality v2)
- Fixes 7-8: NOT yet implemented — add to next session

## COST OPTIMIZATION — SIMBA ARCHITECTURE (PRIORITY #1 for next session)

### The Problem
Floki (Claude Sonnet, $0.16/call) is called every 30 minutes and says WAIT 80% of the time. We're paying $0.16 for him to say "nothing to do" repeatedly. ~24 calls/day = ~$3.50/day = ~$105/month.

### The Solution: Simba (GPT-4o-mini secretary)
Introduce a third AI agent — "Simba" — as Floki's secretary/watchdog. Simba is cheap ($0.002/call) and filters what reaches Floki.

### Three Agents:
- **Floki** (Claude Sonnet 4, $0.16/call) — The boss. Senior trader. Only wakes when it matters. Investigates, analyzes, debates, decides trades.
- **Simba** (GPT-4o-mini, $0.002/call) — The secretary. Monitors conditions Floki defined. Doesn't trade, doesn't debate, doesn't decide. Just watches and alerts.
- **Rex** (GPT-4o, $0.005/turn) — The debate partner. Only called when Floki wants to OPEN or CLOSE a trade.

### Flow:
1. Floki wakes up (H1 close or Simba alert) → investigates all tools → analyzes market → decides
2. If OPEN: Floki debates with Rex → executes if debate supports it
3. If WAIT: Floki tells Simba his wake conditions: "Wake me when: price breaks 5022 with volume above 5000, or bearish engulfing forms on H1, or DXY drops below 100, or ADX crosses 45 with plus DI leading. Max sleep: 2 hours."
4. If HOLD_TRADE: Floki tells Simba trade-specific conditions (existing watch conditions system)
5. Floki sleeps
6. Simba runs every 30 minutes. Receives Scanner data (free). Checks Floki's conditions.
   - If NO condition met → Simba sleeps. Cost: $0.002.
   - If condition MET → Simba wakes Floki with context: "Floki, price broke 5022 at volume 8500. Your condition #1 triggered."
   - If max sleep time expired → Simba wakes Floki: "2 hours passed, nothing triggered, but here's what changed."
7. Rex is NOT involved in Simba's cycle. Simba doesn't need a second opinion to check "did price pass 5022?"

### Why Simba needs to be AI (not just Python):
Python Monitor can check simple things (price > 5022). But Floki's conditions can be complex:
- "Bearish engulfing pattern on H1" — needs candle analysis
- "Volume significantly above average" — needs context judgment
- "DXY showing reversal pattern" — needs interpretation
GPT-4o-mini is smart enough for this but costs 20x less than Sonnet.

### Cost Impact:
Current: 24 Floki calls × $0.16 = $3.84/day
With Simba: 48 Simba calls × $0.002 + 6-8 Floki calls × $0.16 + 3 Rex debates × $0.02 = $0.10 + $1.12 + $0.06 = $1.28/day

Savings: ~$2.50/day = ~$75/month
Monthly cost: ~$38/month (down from ~$105)

### Implementation Plan:
1. Create simba_watcher.py — new file for Simba agent
2. Define wake condition schema (price levels, indicator thresholds, pattern descriptions, max sleep time)
3. Expand set_watch_conditions tool to accept WAIT conditions (not just HOLD_TRADE)
4. Update agent_prompts.py — Floki MUST define wake conditions on WAIT
5. Update main.py — replace "call Floki every H1" with "call Simba every 30 min, Floki only on trigger"
6. Simba receives: Scanner data + Floki's conditions. Returns: WAKE_FLOKI or SLEEP with reason.

### Additional Cost Optimizations (lower priority):
- Send fewer S/R zones to Floki (nearest 10 instead of 58)
- Send fewer candles (H1: 10, H4: 5, D1: 5, M5: 10)
- Rex debate only on OPEN/CLOSE (skip debate for WAIT/HOLD)
