# FLOKIWATCH SESSION STATE — 2026-03-17T12:30Z
# PICKUP: paste this + FLOKIWATCH_HANDOFF_COMPLETE.md in new conv

## ACTIVE_BUG [CRITICAL] — EA kills trades early
brain_signal.json: be_trigger=15, tr_trigger=25, tr_dist=12
SHOULD_BE: be=173, tr=243, dist=170 (for 347pip SL)
ROOT_CAUSE_THEORY: Floki Agent outputs breakeven_trigger:1.5 (points) in trade_plan → main.py Block_B line~1917 does `float(1.5)*10=15` → EA activates BE at 15pips instead of 173
EVIDENCE: 2 trades closed SL-in-profit ($1.05,$1.12) — EA moved SL to entry too early
BLOCKED_ON: DB query to confirm Agent raw_response contains breakeven_trigger field
TODO: run `python` interactive → `import sqlite3,json;conn=sqlite3.connect('data/history.db');row=conn.execute("SELECT raw_response FROM agent_proactive_analyses WHERE agent_decision='OPEN_BUY' ORDER BY timestamp DESC LIMIT 1").fetchone();d=json.loads(row[0]);tp=d.get('trade_plan') or d.get('entry_conditions') or {};print('BE:',tp.get('breakeven_trigger'));print('TR:',tp.get('trailing_trigger'));print('DIST:',tp.get('trailing_distance'))` → if BE=1.5 → FIX: either remove override or fix Agent prompt to output pips not points

## SYSTEM STATE
bal=$819.14 | demo | 2W/0L today | trades:#1536174376(SELL+$1.05),#1536658816(BUY+$1.12)
bot_running=YES | last_restart=08:11UTC | commit_head≈d83c388

## GEMINI MIGRATION [DONE but UNVERIFIED at runtime]
commits: 682c07c(Simba→gemini-2.5-flash-lite), d83c388(Rex→gemini-2.5-flash)
config confirmed: SIMBA_MODEL=gemini-2.5-flash-lite, REX_MODEL=gemini-2.5-flash
GEMINI_API_KEY in .env=YES | pip install google-genai=DONE
UNVERIFIED: no runtime log evidence yet (bot may not have restarted with Gemini commits)
Floki stays Claude Sonnet 4.6 — NO CHANGE

## SIMBA [WORKING but FALSE WAKES]
architecture: Simba(GPT4o-mini→Gemini Flash-Lite) checks Floki wake_conditions every H1
stats_today: 10 SLEEP, 9 WAKE (too many false WAKE)
false_wake_examples: "5021.80 broke below 5010"(WRONG), "approaching 5037.98"(NOT MET)
fix_committed: e7cd5a6 (strict threshold eval prompt) — needs restart to verify
personality_committed: 7105c7a (Simba identity+"Boss, heads up!" style)

## REX [TOO AGGRESSIVE]
stats: 26 turns, 19 DISAGREE(73%), 7 AGREE — still blocking too much
rebalance_committed: 13aa202 (supportive colleague not blocker)
debate_v2_committed: fa06f6c (shorter, more direct, no lists)
UNVERIFIED: rebalance may not be active in running process

## PENDING_COMMITS (pushed but unverified at runtime)
e7cd5a6 — Simba strict eval
7105c7a — Simba personality
13aa202 — Rex rebalance
fa06f6c — Rex debate v2
682c07c — Simba→Gemini
d83c388 — Rex→Gemini
33fd86c — disable data_checklist
f66a138 — Simba msgs in Trade Room feed
ec0f72e — cache usage logging
d1216dd — prompt caching

## TRADE_ROOM ISSUES
- Floki/Rex avatar videos not showing (HTML intact, mp4s serve 200, JS issue)
- Simba card shows "Check complete 0/2..." but too generic (personality fix committed)
- Debates not visible in feed (needs dashboard server restart with f66a138)

## CONFIRMED WORKING (30+ items)
tool_use✓ session_memory✓ debate✓ execute_trade✓ reflection✓ balance_diff✓ deal_resolver✓ schema_bridge✓ candles_multi_tf✓ fibonacci_multi_tf✓ indicators✓ sr_zones(58)✓ macro✓ headlines✓ calendar✓ ml_prediction✓ monitor_events✓ watch_conditions_SET✓ watch_conditions_EVAL✓ entry_conditions_fallback✓ prompt_caching(40-50%)✓ wake_conditions_SET✓ simba_gating✓

## COST
mar16=$33.86(outlier,18restarts) | normal~$3.50/day | with_simba_target~$1.28/day
prompt_cache_rate=40-50% | simba_saved=7calls=$1.12

## KEY_FILES
main.py(orchestrator+schema_bridge+agent_exec) ai_agent.py(claude_tool_loop+cache) agent_tools.py(19tools+wake_conditions) agent_prompts.py(floki_personality) rex_validator.py(rex→gemini) simba_watcher.py(simba→gemini) central_brain.py(scanner) monitor.py(position_mgmt) agent_monitor.py(6triggers) ea_bridge.py(json_protocol) mql5/FlokiBridge.mq5(EA)

## NEXT_SESSION_PRIORITIES
1. FIX EA breakeven bug (confirm Agent override theory → fix)
2. VERIFY Gemini migration runtime (Simba+Rex)
3. VERIFY Simba strict eval (no false WAKE)
4. VERIFY Rex rebalance (more AGREE)
5. FIX Trade Room (videos, debates in feed, Simba msgs)
6. Cost optimization (Simba reduces calls → target $1.28/day)
